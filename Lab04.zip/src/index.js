"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const body_parser_1 = __importDefault(require("body-parser"));
const pg_1 = require("pg");
const pool = new pg_1.Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'Lab02W',
    password: '12345',
    port: 5433,
});
function startServer() {
    return __awaiter(this, void 0, void 0, function* () {
        const app = (0, express_1.default)();
        const connection = yield pool.connect();
        app.use(body_parser_1.default.json());
        app.use(body_parser_1.default.urlencoded({ extended: true }));
        app
            .get('/', (_, response) => {
            // Assuming your index.html is in the 'public' folder
            response.sendFile('index.html', { root: __dirname + '/public' });
        })
            .get('/channels', (_, response) => __awaiter(this, void 0, void 0, function* () {
            const result = yield connection.query('SELECT * FROM channels ORDER BY name');
            response.json(result.rows);
        }))
            .get('/messages/:channelName', (req, response) => __awaiter(this, void 0, void 0, function* () {
            const result = yield connection.query(
            /* sql */ `
        select messages.* from messages 
        inner join channels on messages.channel_id = channels.id 
        where name = $1
      `, [req.params.channelName]);
            console.log('DB results', result.rows);
            response.json(result.rows);
        }))
            .use(express_1.default.static('public'))
            .listen(3000, () => {
            console.log('Server has started at http://localhost:3000');
        });
    });
}
startServer();
