import express from 'express';
import bodyParser from 'body-parser';
import { Pool } from 'pg';

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'Lab02W',
  password: '12345',
  port: 5433,
});

async function startServer() {
  const app = express();
  const connection = await pool.connect();

  
  app.use(bodyParser.json());
  app.use(bodyParser.urlencoded({ extended: true }));

  app
  .get('/', (_, response) => {
    // Assuming your index.html is in the 'public' folder
    response.sendFile('index.html', { root: __dirname + '/public' });
  })
    .get('/channels', async (_, response) => {
      const result = await connection.query(
        'SELECT * FROM channels ORDER BY name',
      );
      response.json(result.rows);
    })
    .get('/messages/:channelName', async (req, response) => {
      const result = await connection.query(
        /* sql */ `
        select messages.* from messages 
        inner join channels on messages.channel_id = channels.id 
        where name = $1
      `,
        [req.params.channelName],
      );
      console.log('DB results', result.rows);
      response.json(result.rows);
    })
    .use(express.static('public'))
    .listen(3000, () => {
      console.log('Server has started at http://localhost:3000');
    });
}

startServer();
